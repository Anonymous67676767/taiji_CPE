#!/bin/sh
# ============================================================
#  太极CPE 一键部署/升级脚本（自包含，无需额外脚本）
#
#  本脚本同时支持首次部署和OTA升级，已废弃 upgrade.sh。
#
#  远程安装: export url='https://your-cdn.com/taichi_cpe' && wget -q --no-check-certificate -O /tmp/install.sh $url/install.sh && sh /tmp/install.sh
#  ADB安装:  adb push install.sh /tmp/ && adb push taichi_cpe-ota-*.tar.gz /run/ota.tar.gz && adb shell "sh /tmp/install.sh"
#  OTA升级: 由后端 ota.rs 调用，暂存目录默认使用 /run/ota_staging
#  本地安装: sh /tmp/install.sh  (可先解压OTA包到 /run/ota_staging)
#
#  Copyright (c) 2025-2026 by capfyun, All Rights Reserved.
# ============================================================

export PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/home/root:$PATH

# ==================== 配置区 ====================
# 网络超时设置（秒）—— 必须在首次使用前定义
CONNECT_TIMEOUT=10
MAX_TIME=120
# 远程下载时，先从JSON获取OTA下载地址
JSON_URL="https://raw.giteeusercontent.com/capfyun/taichi_cpe/raw/master/info.json"
# 用wget或curl获取JSON中的ota_url，兼容压缩/格式化后的空格
# BusyBox wget 不支持 --connect-timeout，统一使用 -T 保持设备端兼容。
OTA_URL=""
# 下载地址（优先使用JSON中的ota_url，可通过环境变量 url 覆盖）
BASE_URL="${url:-}"

# 当前版本号
VERSION="1.260921.4_c"

# OTA包文件名
OTA_PKG="taichi_cpe-ota-${VERSION}.tar.gz"
case "$BASE_URL" in
    *.tar.gz|*.tgz) DOWNLOAD_URL="$BASE_URL" ;;
    *) DOWNLOAD_URL="${BASE_URL%/}/${OTA_PKG}" ;;
esac

# 临时目录
# /tmp 在部分 UDX710 固件上挂载到很小的 userdata 分区，完整 OTA 会因空间不足失败。
# /run 是 tmpfs，优先用于 OTA 包和解压暂存；可通过 TAICHI_OTA_TMP_BASE 覆盖。
TMP_BASE="${TAICHI_OTA_TMP_BASE:-}"
if [ -z "$TMP_BASE" ]; then
    if [ -d /run ] && [ -w /run ]; then
        TMP_BASE="/run"
    else
        TMP_BASE="/tmp"
    fi
fi
TMP_DIR="${TMP_BASE%/}/taichi_install"
STAGING="${TMP_BASE%/}/ota_staging"
LOG_FILE="/tmp/taichi_install.log"

# log 函数（需在设备检测前定义）
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

# ==================== 设备检测与路径选择 ====================
# SY108 设备: 部署到 /taichi/，端口 80，清理旧的 /home/root/taichi 和 TaiChi_CPE
# 非 SY108:   部署到 /home/root/taichi/，端口 8686
# CP100（RG200U-CN 模组）必须走非 SY108 分支：/home/root 是部署根，
# capfyun 层（capfyun.rc/loader.sh/busybox-aarch64/ShellCrash）与太极共用该目录
detect_sy108() {
    # 1. /proc/cmdline 中的 product.name 包含 SY108（最强判据，SY108 实测含 product.name=SY108-688）
    if grep -q "product.name=SY108" /proc/cmdline 2>/dev/null; then
        return 0
    fi
    # 1.5 CP100 排除判据（必须先于判据2的 UDX710 泛匹配）：
    #     CP100 的 /proc/device-tree/model 同样是 "Spreadtrum UDX710_4h10 Board"，
    #     不排除会被判据2误判为 SY108 → 部署路径(/taichi)/端口(80)/home 清理全错，
    #     对 CP100 是毁灭性的（/ 为只读 squashfs，且 /home/root/* 被清空）。
    #     /etc/quectel-project-name 为移远模组身份文件，CP100 R2 实测含
    #     module_model=RG200U-CN 与 fw_version=CP100R2.V01；SY108 命中判据1，不受影响。
    if [ -f /etc/quectel-project-name ]; then
        if grep -q "RG200U" /etc/quectel-project-name 2>/dev/null; then
            return 1
        fi
    fi
    # 2. /proc/device-tree/model 包含 UDX710（UDX710 平台即 SY108 系列）
    if [ -f /proc/device-tree/model ]; then
        if grep -q "UDX710" /proc/device-tree/model 2>/dev/null; then
            return 0
        fi
    fi
    # 3. /taichi/device_model 覆盖文件包含 SY108
    if [ -f /taichi/device_model ]; then
        if grep -q "SY108" /taichi/device_model 2>/dev/null; then
            return 0
        fi
    fi
    # 4. 已有 /taichi/ 部署（升级场景）
    if [ -d /taichi ] && [ -f /taichi/taichi_cpe ]; then
        return 0
    fi
    return 1
}

# MF650 设备检测（高通 SDX55，v1.260829.3）：systemd 管理、部署 /data/taichi、
# 端口 8686。必须先于 detect_sy108 的 else 分支判定，否则会错装到
# /home/root/taichi（MF650 无 inittab/loader.sh 链，语义完全不符）
detect_mf650() {
    grep -q "SDXPRAIRIE" /proc/cpuinfo 2>/dev/null && return 0
    [ -f /data/taichi/taichi_cpe ] && [ ! -f /etc/inittab ] && return 0
    return 1
}

if detect_mf650; then
    IS_SY108=0
    IS_MF650=1
    APP_DIR="/data/taichi"
    PORT=8686
elif detect_sy108; then
    IS_SY108=1
    IS_MF650=0
    APP_DIR="/taichi"
    PORT=80
else
    IS_SY108=0
    IS_MF650=0
    APP_DIR="/home/root/taichi"
    PORT=8686
fi
export TAICHI_APP_DIR="$APP_DIR"
export TAICHI_PORT="$PORT"
log "设备检测: IS_SY108=$IS_SY108, APP_DIR=$APP_DIR, PORT=$PORT"

# When invoked by old CPE OTA backends, install.sh is executed directly from
# the already extracted ota_staging directory. Prefer that local payload instead
# of falling back to /run/ota_staging or remote download.
SCRIPT_DIR="$(cd "$(dirname "$0")" 2>/dev/null && pwd)"
if [ -n "$SCRIPT_DIR" ] && { [ -f "$SCRIPT_DIR/udx710.tar.gz" ] || [ -f "$SCRIPT_DIR/meta.json" ] || [ -d "$SCRIPT_DIR/taichi" ] || [ -d "$SCRIPT_DIR/TaiChi_CPE" ] || [ -f "$SCRIPT_DIR/taichi_cpe" ]; }; then
    STAGING="$SCRIPT_DIR"
    TMP_BASE="$(dirname "$SCRIPT_DIR")"
    TMP_DIR="${TMP_BASE%/}/taichi_install"
fi
# ==================== 配置区结束 ====================

ensure_rndis_usb_mode() {
    # MF650：/mnt/data 是 taichi license/UID 持久层（rootfs），mode.cfg/virtualcn
    # 是 UDX710 专有的 RNDIS 枚举配置——写入无效且污染持久目录，跳过
    if [ "$IS_MF650" = "1" ]; then
        return
    fi
    for data_dir in /mnt/data /m_data; do
        [ -d "$data_dir" ] || continue
        echo 3 > "$data_dir/mode.cfg" 2>/dev/null
        echo 3 > "$data_dir/mode_tmp.cfg" 2>/dev/null
        echo 0 > "$data_dir/virtualcn" 2>/dev/null
        echo 1 > "$data_dir/AfterPowerLoss" 2>/dev/null
        if [ -f "$data_dir/usbenum.ini" ]; then
            sed -i 's/^virtualcn=.*/virtualcn=0/' "$data_dir/usbenum.ini" 2>/dev/null
            sed -i 's/^AfterPowerLoss=.*/AfterPowerLoss=1/' "$data_dir/usbenum.ini" 2>/dev/null
        fi
    done
    sync 2>/dev/null
}

# 显示Banner
log "=========================================="
log "  太极CPE 一键安装 v${VERSION}"
log "=========================================="

# ==================== 阶段1: 准备OTA包 ====================

# 检查是否已有本地OTA包或已解压的OTA包
# v1.260820.1 修复：本地OTA包（/run/ota.tar.gz，用户/工具显式推送）必须优先于
# staging 残留——上轮安装结束后 /run/ota_staging 不清理，同版本号迭代刷入时
# 残留的旧二进制会压过新推送的包，导致部署旧版本（已实测复现）。
mkdir -p /m_data 2>/dev/null
ensure_rndis_usb_mode
LOCAL_OTA=""
if [ -f "${TMP_BASE%/}/ota.tar.gz" ]; then
    LOCAL_OTA="${TMP_BASE%/}/ota.tar.gz"
elif [ -f "/tmp/ota.tar.gz" ]; then
    LOCAL_OTA="/tmp/ota.tar.gz"
elif [ -f "$STAGING/ota.tar.gz" ]; then
    LOCAL_OTA="$STAGING/ota.tar.gz"
elif [ -f "$(dirname "$0")/ota.tar.gz" ]; then
    LOCAL_OTA="$(dirname "$0")/ota.tar.gz"
fi

if [ -n "$LOCAL_OTA" ]; then
    log "[1] 解压本地OTA包..."
    mkdir -p "$STAGING"
    case "$LOCAL_OTA" in
        "$STAGING"/*)
            rm -rf "$STAGING/TaiChi_CPE" "$STAGING/taichi" "$STAGING/home" "$STAGING/taichi_cpe" "$STAGING/www" "$STAGING/udx710.tar.gz" "$STAGING/meta.json" 2>/dev/null
            ;;
        *)
            rm -rf "$STAGING"
            mkdir -p "$STAGING"
            ;;
    esac
    tar xzf "$LOCAL_OTA" -C "$STAGING"
    if [ $? -ne 0 ]; then
        log "[错误] OTA包解压失败！"
        exit 1
    fi
    rm -f "$LOCAL_OTA" 2>/dev/null || true
    log "  解压完成"
elif [ -d "$STAGING" ] && ([ -f "$STAGING/taichi_cpe" ] || [ -f "$STAGING/taichi/taichi_cpe" ] || [ -f "$STAGING/TaiChi_CPE/taichi_cpe" ] || [ -f "$STAGING/home/root/TaiChi_CPE/taichi_cpe" ]); then
    log "检测到已解压的OTA包，跳过下载"
else
        # 远程下载
        log "[1] 从远程下载OTA包..."

        if [ -z "$BASE_URL" ]; then
            if command -v curl >/dev/null 2>&1; then
                OTA_URL=$(curl --connect-timeout "$CONNECT_TIMEOUT" --max-time "$MAX_TIME" -ks "$JSON_URL" 2>/dev/null | sed -n 's/.*"ota_url"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -n 1)
            fi
            if [ -z "$OTA_URL" ] && command -v wget >/dev/null 2>&1; then
                OTA_URL=$(wget -T "$MAX_TIME" -qO- "$JSON_URL" 2>/dev/null | sed -n 's/.*"ota_url"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -n 1)
            fi
            BASE_URL="${OTA_URL:-https://your-cdn.com/taichi_cpe}"
            case "$BASE_URL" in
                *.tar.gz|*.tgz) DOWNLOAD_URL="$BASE_URL" ;;
                *) DOWNLOAD_URL="${BASE_URL%/}/${OTA_PKG}" ;;
            esac
        fi
        log "  下载地址已解析"

        mkdir -p "$TMP_DIR"
        DL_OK=0
        if command -v curl >/dev/null 2>&1; then
            curl --connect-timeout "$CONNECT_TIMEOUT" --max-time "$MAX_TIME" -kso "${TMP_DIR}/ota.tar.gz" "${DOWNLOAD_URL}" && DL_OK=1
        fi
        if [ "$DL_OK" -eq 0 ] && command -v wget >/dev/null 2>&1; then
            wget -T "$MAX_TIME" -q -O "${TMP_DIR}/ota.tar.gz" "${DOWNLOAD_URL}" && DL_OK=1
        fi
        if ! command -v curl >/dev/null 2>&1 && ! command -v wget >/dev/null 2>&1; then
            log "[错误] 未找到 wget 或 curl，无法下载文件"
            exit 1
        fi

        if [ "$DL_OK" -eq 0 ] || [ ! -f "${TMP_DIR}/ota.tar.gz" ]; then
            log "[错误] OTA包下载失败！"
            log "  请检查网络连接"
            exit 1
        fi

        OTA_SIZE=$(ls -l "${TMP_DIR}/ota.tar.gz" 2>/dev/null | awk '{print $5}')
        if [ -z "$OTA_SIZE" ] || [ "$OTA_SIZE" -lt 1024 ]; then
            log "[错误] OTA包大小异常 (${OTA_SIZE} bytes)，可能下载不完整"
            rm -rf "$TMP_DIR"
            exit 1
        fi
        log "  下载完成 (${OTA_SIZE} bytes)"

        rm -rf "$STAGING"
        mkdir -p "$STAGING"
        tar xzf "${TMP_DIR}/ota.tar.gz" -C "$STAGING"
        if [ $? -ne 0 ]; then
            log "[错误] OTA包解压失败！"
            exit 1
        fi
        rm -f "${TMP_DIR}/ota.tar.gz" 2>/dev/null || true
        log "  解压完成"
fi

# v2 OTA package: outer archive contains install.sh + udx710.tar.gz.
# Extract the runtime payload before running the existing structure detector.
if [ -f "$STAGING/udx710.tar.gz" ]; then
    log "检测到v2 OTA载荷 udx710.tar.gz，正在解压..."
    tar xzf "$STAGING/udx710.tar.gz" -C "$STAGING"
    if [ $? -ne 0 ]; then
        log "[错误] udx710.tar.gz 解压失败！"
        exit 1
    fi
    log "  v2 OTA载荷解压完成"
fi

# ==================== 阶段2: 检测OTA包目录结构 ====================

if [ -f "$STAGING/taichi_cpe" ] || [ -d "$STAGING/www" ]; then
    SRC_DIR="$STAGING"
    log "检测到扁平结构OTA包"
elif [ -f "$STAGING/taichi/taichi_cpe" ]; then
    SRC_DIR="$STAGING/taichi"
    log "检测到taichi子目录结构OTA包"
elif [ -f "$STAGING/TaiChi_CPE/taichi_cpe" ]; then
    SRC_DIR="$STAGING/TaiChi_CPE"
    log "检测到TaiChi_CPE子目录结构OTA包"
elif [ -f "$STAGING/home/root/TaiChi_CPE/taichi_cpe" ]; then
    SRC_DIR="$STAGING/home/root/TaiChi_CPE"
    log "检测到嵌套结构OTA包（home/root/TaiChi_CPE/前缀）"
elif [ -d "$STAGING/home/root" ]; then
    SRC_DIR="$STAGING/home/root"
    log "检测到嵌套目录结构"
else
    log "[错误] 无法识别OTA包结构"
    log "暂存目录内容:"
    ls -la "$STAGING/" 2>/dev/null
    exit 1
fi

# ==================== 阶段2.5: 载荷硬校验与镜像 ====================
# v1.260819.1 修复（P0：升级后 /taichi 被清空）：阶段3 killall 后 inittab 会
# respawn 新 taichi_cpe，其启动清理任务会删除 /tmp/ota_staging——若安装仍直接
# 读 staging，rm -rf /taichi 之后将无源可装。故在改动系统之前：
# 1) 硬校验载荷（二进制+前端齐全，否则零损伤退出）
# 2) 镜像到本脚本私有的 /tmp/taichi_payload（不被任何清理任务识别）
# 3) 后续安装一律从镜像读取，原 staging 生死无关紧要
PAYLOAD_MIRROR="${TMP_BASE%/}/taichi_payload"
# v1.260820.1：镜像前空间自检。外部调用（TAICHI_OTA_TMP_BASE）可能把暂存
# 指到 userdata 等小分区，cp 静默截断后安装源残缺（表现为升级后文件随机
# 缺失，如 start.sh 丢失）。需求 = 载荷实际大小 + 20% 余量，不足时改用 /run。
MIRROR_NEED_KB=$(( $(du -sk "$STAGING" 2>/dev/null | awk '{print $1}') * 12 / 10 + 4096 ))
MIRROR_AVAIL_KB=$(df -Pk "${TMP_BASE%/}" 2>/dev/null | tail -1 | awk '{print $4}')
if [ -n "$MIRROR_AVAIL_KB" ] && [ -n "$MIRROR_NEED_KB" ] && [ "$MIRROR_AVAIL_KB" -lt "$MIRROR_NEED_KB" ] 2>/dev/null; then
    RUN_AVAIL_KB=$(df -Pk /run 2>/dev/null | tail -1 | awk '{print $4}')
    if [ -n "$RUN_AVAIL_KB" ] && [ "$RUN_AVAIL_KB" -ge "$MIRROR_NEED_KB" ] 2>/dev/null; then
        log "  [警告] $TMP_BASE 可用空间不足(${MIRROR_AVAIL_KB}KB < ${MIRROR_NEED_KB}KB)，镜像改用 /run"
        PAYLOAD_MIRROR="/run/taichi_payload"
    else
        log "  [警告] $TMP_BASE 与 /run 空间均不足，镜像可能不完整（需要 ${MIRROR_NEED_KB}KB）"
    fi
fi
log "[2.5] 校验并镜像OTA载荷..."
STAGED_BIN=""
for bin_path in "$STAGING/taichi/taichi_cpe" "$STAGING/TaiChi_CPE/taichi_cpe" "$STAGING/taichi_cpe" "$STAGING/home/root/TaiChi_CPE/taichi_cpe"; do
    if [ -f "$bin_path" ]; then
        STAGED_BIN="$bin_path"
        break
    fi
done
if [ -z "$STAGED_BIN" ]; then
    log "  [错误] OTA载荷缺少后端二进制，中止安装（系统未做任何改动）"
    exit 1
fi
if [ ! -d "$STAGING/taichi/www" ] && [ ! -d "$STAGING/www" ] && [ ! -d "$STAGING/TaiChi_CPE/www" ]; then
    log "  [错误] OTA载荷缺少前端文件，中止安装（系统未做任何改动）"
    exit 1
fi
rm -rf "$PAYLOAD_MIRROR"
mkdir -p "$PAYLOAD_MIRROR"
cp -a "$STAGING/." "$PAYLOAD_MIRROR/" 2>/dev/null
# v1.260827.3 修复：镜像完整性必须逐文件校验。载荷 tar 内二进制位于首部，
# tmpfs 空间不足时 cp 静默截断，二进制已复制而尾部小文件（如
# taichi/resources/baseband_default.tar.gz）缺失——旧逻辑仅验二进制会放行，
# 造成"升级成功但基带还原文件丢失"。文件数不一致即零损伤退出。
STAGING_COUNT=$(find "$STAGING" -type f 2>/dev/null | wc -l)
MIRROR_COUNT=$(find "$PAYLOAD_MIRROR" -type f 2>/dev/null | wc -l)
# STAGED_BIN 是 $STAGING 下的绝对路径，校验镜像必须先转相对路径——直接拼接
# $PAYLOAD_MIRROR/$STAGED_BIN 会得到 /tmp/taichi_payload//run/ota_staging/...，
# 恒不存在，校验必然误报中止（v1.260827.3 首轮实测复现）。
STAGED_BIN_REL="${STAGED_BIN#"$STAGING"/}"
if [ "$MIRROR_COUNT" -ne "$STAGING_COUNT" ] || [ ! -f "$PAYLOAD_MIRROR/$STAGED_BIN_REL" ]; then
    log "  [错误] OTA载荷镜像不完整（${MIRROR_COUNT}/${STAGING_COUNT} 个文件或二进制缺失），中止安装（系统未做任何改动）"
    rm -rf "$PAYLOAD_MIRROR"
    exit 1
fi
MIRRORED_BIN="$PAYLOAD_MIRROR/$STAGED_BIN_REL"
[ -f "$MIRRORED_BIN" ] || MIRRORED_BIN=$(find "$PAYLOAD_MIRROR" -name taichi_cpe -type f 2>/dev/null | sed -n '1p')
if [ -z "$MIRRORED_BIN" ] || [ ! -f "$MIRRORED_BIN" ]; then
    log "  [错误] 镜像中未找到后端二进制，中止安装（系统未做任何改动）"
    rm -rf "$PAYLOAD_MIRROR"
    exit 1
fi
log "  载荷镜像完成: $MIRRORED_BIN"
# 安装源切换到镜像目录，并按阶段2同规则重算 SRC_DIR（镜像结构=原staging完整拷贝）
STAGING="$PAYLOAD_MIRROR"
if [ -f "$STAGING/taichi_cpe" ] || [ -d "$STAGING/www" ]; then
    SRC_DIR="$STAGING"
elif [ -f "$STAGING/taichi/taichi_cpe" ]; then
    SRC_DIR="$STAGING/taichi"
elif [ -f "$STAGING/TaiChi_CPE/taichi_cpe" ]; then
    SRC_DIR="$STAGING/TaiChi_CPE"
elif [ -f "$STAGING/home/root/TaiChi_CPE/taichi_cpe" ]; then
    SRC_DIR="$STAGING/home/root/TaiChi_CPE"
elif [ -f "$STAGING/home/root/taichi/taichi_cpe" ]; then
    SRC_DIR="$STAGING/home/root"
else
    SRC_DIR="$STAGING"
fi

# ==================== 阶段3: 执行安装 ====================

log "[2] 停止所有服务..."
# BusyBox兼容进程检测（设备无pgrep）
is_running() { pidof "$1" > /dev/null 2>&1; }

# 检测并强杀绑定80端口的进程（防止旧版taichi_cpe或httpd占用端口导致新服务无法启动）
# 仅 SY108：太极监听 80。非 SY108（CP100 等）80 端口属原厂面板（lighttpd），
# 强杀会破坏原厂 Web 与注入通道，必须跳过（太极自身使用 $PORT=8686）
if [ "$IS_SY108" -eq 1 ]; then
    if command -v fuser >/dev/null 2>&1; then
        PORT80_PID=$(fuser 80/tcp 2>/dev/null)
        if [ -n "$PORT80_PID" ]; then
            log "  检测到80端口被占用(PID: $PORT80_PID)，强制终止..."
            fuser -k 80/tcp 2>/dev/null
            sleep 1
        fi
    elif command -v netstat >/dev/null 2>&1; then
        PORT80_PID=$(netstat -tlnp 2>/dev/null | grep ':80 ' | awk '{print $NF}' | cut -d/ -f1 | head -1)
        if [ -n "$PORT80_PID" ]; then
            log "  检测到80端口被占用(PID: $PORT80_PID)，强制终止..."
            kill -9 "$PORT80_PID" 2>/dev/null
            sleep 1
        fi
    fi
else
    log "  非SY108设备：跳过80端口清理（80=原厂面板，太极使用端口 $PORT）"
fi

killall taichi_cpe_c 2>/dev/null
killall taichi_cpe 2>/dev/null
killall yf_udx710 2>/dev/null
killall udx710 2>/dev/null

# 等待旧进程完全退出（最多15秒），超时则强杀
WAIT_COUNT=0
while is_running taichi_cpe || is_running taichi_cpe_c; do
    WAIT_COUNT=$((WAIT_COUNT + 1))
    if [ "$WAIT_COUNT" -ge 15 ]; then
        log "  旧进程未响应SIGTERM，强制终止..."
        killall -9 taichi_cpe 2>/dev/null
        killall -9 taichi_cpe_c 2>/dev/null
        sleep 1
        break
    fi
    sleep 1
done
[ "$WAIT_COUNT" -gt 0 ] && log "  taichi_cpe 等待退出 ${WAIT_COUNT} 秒"

# v1.260827.4 修复（安装窗口竞态，SY108 实测复现）：killall 后 loader.sh 10s
# 退避即重启 start.sh，此时 [4] 正在 rm -rf 重建部署目录，respawn 的 start.sh
# 因二进制缺失短命死亡（<60s），触发 loader.sh 130s 长退避——服务中断从 ~30s
# 拉长到 ~2.5 分钟。移除旧 start.sh 让 respawn 的 loader.sh 走 "not found →
# sleep 130" 路径（respawn 周期 >2min 永不触发 sysvinit 禁用，且不会执行
# 半安装状态目录）；[10] 阶段终止 loader.sh 触发立即 respawn 拉起新版本。
rm -f "$APP_DIR/start.sh" 2>/dev/null

if [ -f "/taichi/ShellCrash/start.sh" ]; then
    sh /taichi/ShellCrash/start.sh stop 2>/dev/null
elif [ -f "/home/root/ShellCrash/start.sh" ]; then
    sh /home/root/ShellCrash/start.sh stop 2>/dev/null
fi
sleep 2
log "  所有服务已停止"

# 清理旧版ttyd（已内置到后端，不再需要外部ttyd）
if [ -d "/home/root/ttyd" ]; then
    killall ttyd 2>/dev/null
    rm -rf /home/root/ttyd
    log "  已清理旧版ttyd目录"
fi

# [3] 备份ShellCrash用户配置
log "[3] 备份ShellCrash用户配置..."
BACKUP_DIR="/tmp/taichi_backup"
rm -rf "$BACKUP_DIR"
mkdir -p "$BACKUP_DIR"
ensure_rndis_usb_mode

if [ -d "/taichi/ShellCrash/configs" ]; then
    cp -r /taichi/ShellCrash/configs "$BACKUP_DIR/sc_configs" 2>/dev/null
    log "  已备份ShellCrash配置"
elif [ -d "/home/root/ShellCrash/configs" ]; then
    cp -r /home/root/ShellCrash/configs "$BACKUP_DIR/sc_configs" 2>/dev/null
    log "  已备份ShellCrash配置"
fi
if [ -d "/taichi/ShellCrash/yamls" ]; then
    cp -r /taichi/ShellCrash/yamls "$BACKUP_DIR/sc_yamls" 2>/dev/null
elif [ -d "/home/root/ShellCrash/yamls" ]; then
    cp -r /home/root/ShellCrash/yamls "$BACKUP_DIR/sc_yamls" 2>/dev/null
fi
for cfg in /m_data/mode.cfg /m_data/mode_tmp.cfg; do
    if [ -f "$cfg" ]; then
        cp "$cfg" "$BACKUP_DIR/" 2>/dev/null
        log "  已备份 $(basename $cfg)"
    fi
done
# 备份CPE授权和数据（如果存在且非空）
# license 和 device_uid 统一存储到 /mnt/data/（主路径），兼容旧版 /m_data/
mkdir -p /m_data
mkdir -p /mnt/data 2>/dev/null
# device_uid 备份（关键：保证刷机/重置后 UID 稳定）
for uid_path in /mnt/data/device_uid /m_data/device_uid; do
    if [ -f "$uid_path" ] && [ -s "$uid_path" ]; then
        cp "$uid_path" "$BACKUP_DIR/cpe_device_uid" 2>/dev/null
        log "  已备份设备UID（$uid_path）"
        break
    fi
done
# 旧版升级兼容：旧版本(1.260703.5)不持久化device_uid文件，
# 需要从license文件中提取uid字段，确保升级后UID不变
if [ ! -f "$BACKUP_DIR/cpe_device_uid" ] || [ ! -s "$BACKUP_DIR/cpe_device_uid" ]; then
    for lic_path in /mnt/data/license /m_data/license; do
        if [ -f "$lic_path" ] && [ -s "$lic_path" ]; then
            # 从JSON license文件中提取uid字段
            EXTRACTED_UID=$(grep -o '"uid"[[:space:]]*:[[:space:]]*"[^"]*"' "$lic_path" 2>/dev/null | head -1 | sed 's/.*"uid"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/' 2>/dev/null)
            if [ -n "$EXTRACTED_UID" ] && [ ${#EXTRACTED_UID} -ge 16 ]; then
                echo "$EXTRACTED_UID" > "$BACKUP_DIR/cpe_device_uid" 2>/dev/null
                log "  已从license文件提取设备UID（$lic_path -> $EXTRACTED_UID）"
                break
            fi
        fi
    done
fi
# license 备份（主路径 /mnt/data/license，兼容 /m_data/license）
for lic_path in /mnt/data/license /m_data/license; do
    if [ -f "$lic_path" ] && [ -s "$lic_path" ]; then
        cp "$lic_path" "$BACKUP_DIR/cpe_license" 2>/dev/null
        log "  已备份CPE主授权（$lic_path）"
        break
    fi
done
for lic_legacy_path in /mnt/data/license_legacy.json /m_data/license_legacy.json; do
    if [ -f "$lic_legacy_path" ] && [ -s "$lic_legacy_path" ]; then
        cp "$lic_legacy_path" "$BACKUP_DIR/cpe_license_legacy" 2>/dev/null
        log "  已备份CPE旧版授权（$lic_legacy_path）"
        break
    fi
done
if [ -f "/taichi/license" ] && [ -s "/taichi/license" ]; then
    cp "/taichi/license" "$BACKUP_DIR/cpe_license_rollback" 2>/dev/null
    log "  已备份CPE回滚授权（旧版 /taichi/license）"
elif [ -f "$APP_DIR/license" ] && [ -s "$APP_DIR/license" ]; then
    cp "$APP_DIR/license" "$BACKUP_DIR/cpe_license_rollback" 2>/dev/null
    log "  已备份CPE回滚授权（旧版 $APP_DIR/license）"
elif [ -f "/home/root/TaiChi_CPE/license" ] && [ -s "/home/root/TaiChi_CPE/license" ]; then
    cp "/home/root/TaiChi_CPE/license" "$BACKUP_DIR/cpe_license_rollback" 2>/dev/null
    log "  已备份CPE回滚授权（旧版 /home/root/TaiChi_CPE/license）"
fi
if [ ! -s "$BACKUP_DIR/cpe_license" ] && [ -s "$BACKUP_DIR/cpe_license_rollback" ]; then
    cp "$BACKUP_DIR/cpe_license_rollback" "$BACKUP_DIR/cpe_license" 2>/dev/null
fi
if [ ! -s "$BACKUP_DIR/cpe_license_legacy" ] && [ -s "$BACKUP_DIR/cpe_license_rollback" ]; then
    cp "$BACKUP_DIR/cpe_license_rollback" "$BACKUP_DIR/cpe_license_legacy" 2>/dev/null
fi
# 旧版升级兼容：若仍未提取到UID，从所有license备份中尝试提取
if [ ! -f "$BACKUP_DIR/cpe_device_uid" ] || [ ! -s "$BACKUP_DIR/cpe_device_uid" ]; then
    for lic_bak in "$BACKUP_DIR/cpe_license" "$BACKUP_DIR/cpe_license_legacy" "$BACKUP_DIR/cpe_license_rollback"; do
        if [ -f "$lic_bak" ] && [ -s "$lic_bak" ]; then
            EXTRACTED_UID=$(grep -o '"uid"[[:space:]]*:[[:space:]]*"[^"]*"' "$lic_bak" 2>/dev/null | head -1 | sed 's/.*"uid"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/' 2>/dev/null)
            if [ -n "$EXTRACTED_UID" ] && [ ${#EXTRACTED_UID} -ge 16 ]; then
                echo "$EXTRACTED_UID" > "$BACKUP_DIR/cpe_device_uid" 2>/dev/null
                log "  已从license备份提取设备UID（$EXTRACTED_UID）"
                break
            fi
        fi
    done
fi
# data.db 备份（主路径 /mnt/data/data.db，兼容 /m_data/data.db）
for db_path in /mnt/data/data.db /m_data/data.db "$APP_DIR/data.db"; do
    if [ -f "$db_path" ]; then
        cp "$db_path" "$BACKUP_DIR/cpe_data.db" 2>/dev/null
        log "  已备份CPE数据库（$db_path）"
        break
    fi
done
if [ -f "$APP_DIR/config.json" ]; then
    cp "$APP_DIR/config.json" "$BACKUP_DIR/cpe_config.json" 2>/dev/null
fi
log "  备份完成"

# [3.5] 提前清理释放分区空间
# SY108: 部署目标在 /taichi，/home/root 仅存历史残留 → 全清（仅保留 loader.sh）
# 非 SY108（CP100 等）: /home/root 是部署根，capfyun 层（capfyun.rc/loader.sh/
#   busybox-aarch64/ShellCrash）与太极共用此目录 → 仅清理旧版 CPE 目录，其余一律不动
# 备份已保存到 $BACKUP_DIR（/tmp/taichi_backup）
mount -o remount,rw / 2>/dev/null || true
if [ "$IS_SY108" -eq 1 ]; then
    if [ -d "/home/root" ]; then
        # 保留 loader.sh（底层inittab硬编码了/home/root/loader.sh）
        if [ -f "/home/root/loader.sh" ]; then
            mv /home/root/loader.sh /tmp/loader.sh.tmp 2>/dev/null
        fi
        rm -rf /home/root/* 2>/dev/null
        if [ -f "/tmp/loader.sh.tmp" ]; then
            mv /tmp/loader.sh.tmp /home/root/loader.sh 2>/dev/null
            chmod 755 /home/root/loader.sh 2>/dev/null
        fi
        log "  /home/root/* 已清理（SY108，释放分区空间）"
    fi
else
    rm -rf /home/root/TaiChi_CPE /home/root/ttyd 2>/dev/null
    rm -rf /home/root/taichi 2>/dev/null
    log "  旧版CPE目录已清理（非SY108，保留 /home/root 其余文件）"
fi

# [4] 清空旧目录并安装到目标路径
log "[4] 准备安装目录 (APP_DIR=$APP_DIR)..."
# SY108: rootfs 可能只读，需要 remount rw
# 非 SY108: /home/root 已可写，remount 是 no-op
mount -o remount,rw / 2>/dev/null || true
if [ -d "/home/root/TaiChi_CPE" ]; then
    chmod -R u+w /home/root/TaiChi_CPE 2>/dev/null || true
    rm -rf /home/root/TaiChi_CPE
    if [ -d "/home/root/TaiChi_CPE" ]; then
        log "[ERROR] failed to remove old /home/root/TaiChi_CPE"
        exit 1
    fi
    log "  cleaned old /home/root/TaiChi_CPE"
fi
if [ -d "/TaiChi_CPE" ]; then
    chmod -R u+w /TaiChi_CPE 2>/dev/null || true
    rm -rf /TaiChi_CPE
    if [ -d "/TaiChi_CPE" ]; then
        log "[ERROR] failed to remove old /TaiChi_CPE"
        exit 1
    fi
    log "  cleaned old /TaiChi_CPE"
fi
# SY108 设备：清理旧的 /taichi 目录（升级时重建）
# 非 SY108 设备：也清理 /taichi（可能是从 SY108 迁移过来的旧安装）
if [ -d "/taichi" ] && [ "$IS_SY108" -eq 0 ]; then
    chmod -R u+w /taichi 2>/dev/null || true
    rm -rf /taichi
    log "  cleaned old /taichi (non-SY108 mode)"
elif [ -d "/taichi" ] && [ "$IS_SY108" -eq 1 ]; then
    chmod -R u+w /taichi 2>/dev/null || true
    rm -rf /taichi
    if [ -d "/taichi" ]; then
        log "[ERROR] failed to remove old /taichi"
        exit 1
    fi
    log "  cleaned old /taichi"
fi
if [ "$IS_SY108" -eq 1 ]; then
    if [ -f "/home/root/loader.sh" ]; then
        cp /home/root/loader.sh /tmp/loader.sh.tmp 2>/dev/null
    fi
    rm -rf /home/root/*
    if [ -f "/tmp/loader.sh.tmp" ]; then
        cp /tmp/loader.sh.tmp /home/root/loader.sh 2>/dev/null
        chmod 755 /home/root/loader.sh 2>/dev/null
        rm -f /tmp/loader.sh.tmp
    fi
    log "  cleaned /home/root/*"
else
    # 非 SY108：仅清旧版 CPE 目录（[3.5] 已清一次，此处兜底），不动 capfyun 层
    rm -rf /home/root/TaiChi_CPE /home/root/ttyd /home/root/taichi 2>/dev/null
    log "  cleaned old CPE dirs (non-SY108, capfyun layer preserved)"
fi
mkdir -p "$APP_DIR"
log "  $APP_DIR 目录已创建"

# [5] 安装 TaiChi_CPE
log "[5] 安装 TaiChi_CPE..."

# 后端二进制（Rust后台为主文件taichi_cpe，C后台作为备份taichi_cpe_c）
TAICHI_BIN_MAIN=""
TAICHI_BIN_C=""
for bin_path in "$SRC_DIR/taichi/taichi_cpe" "$SRC_DIR/TaiChi_CPE/taichi_cpe" "$SRC_DIR/taichi_cpe" "$STAGING/taichi_cpe"; do
    if [ -f "$bin_path" ]; then
        TAICHI_BIN_MAIN="$bin_path"
        break
    fi
done
for bin_path in "$SRC_DIR/taichi/taichi_cpe_c" "$SRC_DIR/TaiChi_CPE/taichi_cpe_c" "$SRC_DIR/taichi_cpe_c" "$STAGING/taichi_cpe_c"; do
    if [ -f "$bin_path" ]; then
        TAICHI_BIN_C="$bin_path"
        break
    fi
done

# 部署主后台（主文件）
if [ -n "$TAICHI_BIN_MAIN" ]; then
    cp "$TAICHI_BIN_MAIN" "$APP_DIR/taichi_cpe"
    chmod 755 "$APP_DIR/taichi_cpe"
    log "  主后台已安装(taichi_cpe)"
else
    # v1.260819.1 防御纵深：镜像校验后仍找不到二进制属于异常状态，
    # 立即中止并保留备份，绝不留空部署目录
    log "  [错误] 阶段5未找到后端二进制，中止安装（备份已保留于 $BACKUP_DIR）"
    exit 1
fi

# 部署C后台（备份）
if [ -n "$TAICHI_BIN_C" ]; then
    cp "$TAICHI_BIN_C" "$APP_DIR/taichi_cpe_c"
    chmod 755 "$APP_DIR/taichi_cpe_c"
    log "  C语言后台已安装为备份(taichi_cpe_c)"
fi

# 部署完整性校验文件（.integrity 必须与二进制同目录，运行时用于防篡改）
INTEGRITY_SRC=""
for int_path in "$SRC_DIR/taichi/.integrity" "$STAGING/taichi/.integrity" "$SRC_DIR/TaiChi_CPE/.integrity" "$SRC_DIR/.integrity" "$STAGING/.integrity" "$STAGING/TaiChi_CPE/.integrity" "$STAGING/home/root/TaiChi_CPE/.integrity"; do
    if [ -f "$int_path" ]; then
        INTEGRITY_SRC="$int_path"
        break
    fi
done
if [ -n "$INTEGRITY_SRC" ]; then
    cp "$INTEGRITY_SRC" "$APP_DIR/.integrity"
    chmod 644 "$APP_DIR/.integrity"
    log "  完整性校验文件已部署(.integrity)"
else
    log "  [警告] 升级包中无.integrity文件（运行时将拒绝业务API，开发期可用TAICHI_SKIP_INTEGRITY=1绕过）"
fi

# 清理旧版命名文件
rm -f "$APP_DIR/taichi_cpe_rust" 2>/dev/null

if [ -z "$TAICHI_BIN_MAIN" ] && [ -z "$TAICHI_BIN_C" ]; then
    log "  [错误] 升级包中无后端二进制！"
elif [ -n "$TAICHI_BIN_MAIN" ]; then
    log "  后端程序已安装 (主: taichi_cpe)"
else
    log "  后端程序已安装 (仅备份: taichi_cpe_c)"
fi

# 前端文件
WWW_SRC=""
for www_path in "$SRC_DIR/taichi/www" "$SRC_DIR/TaiChi_CPE/www" "$SRC_DIR/www" "$STAGING/www"; do
    if [ -d "$www_path" ]; then
        WWW_SRC="$www_path"
        break
    fi
done

if [ -n "$WWW_SRC" ]; then
    cp -r "$WWW_SRC" "$APP_DIR/www"
    log "  前端文件已安装"
else
    log "  [警告] 升级包中无前端文件"
fi

# 版本号
for ver_path in "$SRC_DIR/taichi/VERSION" "$SRC_DIR/TaiChi_CPE/VERSION" "$SRC_DIR/VERSION" "$STAGING/VERSION"; do
    if [ -f "$ver_path" ]; then
        cp "$ver_path" "$APP_DIR/VERSION"
        break
    fi
done

# 恢复CPE授权和数据（仅当备份文件存在且非空时）
# license 和 device_uid 统一恢复到 /mnt/data/（主路径），同时镜像到 /m_data/（兼容旧版）
mkdir -p /m_data
mkdir -p /mnt/data 2>/dev/null
# device_uid 恢复（关键：保证刷机/重置后 UID 稳定）
if [ -f "$BACKUP_DIR/cpe_device_uid" ] && [ -s "$BACKUP_DIR/cpe_device_uid" ]; then
    cp "$BACKUP_DIR/cpe_device_uid" /mnt/data/device_uid 2>/dev/null
    cp "$BACKUP_DIR/cpe_device_uid" /m_data/device_uid 2>/dev/null
    chmod 644 /mnt/data/device_uid 2>/dev/null
    chmod 644 /m_data/device_uid 2>/dev/null
    sync 2>/dev/null
    log "  已恢复设备UID到 /mnt/data/device_uid 和 /m_data/device_uid"
fi
# license 恢复（主路径 /mnt/data/license，镜像到 /m_data/license）
if [ -f "$BACKUP_DIR/cpe_license" ] && [ -s "$BACKUP_DIR/cpe_license" ]; then
    cp "$BACKUP_DIR/cpe_license" /mnt/data/license 2>/dev/null
    cp "$BACKUP_DIR/cpe_license" /m_data/license 2>/dev/null
    chmod 644 /mnt/data/license 2>/dev/null
    chmod 644 /m_data/license 2>/dev/null
    log "  已恢复CPE主授权到 /mnt/data/license 和 /m_data/license"
fi
if [ -f "$BACKUP_DIR/cpe_license_legacy" ] && [ -s "$BACKUP_DIR/cpe_license_legacy" ]; then
    cp "$BACKUP_DIR/cpe_license_legacy" /mnt/data/license_legacy.json 2>/dev/null
    cp "$BACKUP_DIR/cpe_license_legacy" /m_data/license_legacy.json 2>/dev/null
    chmod 644 /mnt/data/license_legacy.json 2>/dev/null
    chmod 644 /m_data/license_legacy.json 2>/dev/null
    log "  已恢复CPE旧版授权到 /mnt/data/license_legacy.json 和 /m_data/license_legacy.json"
fi

# 清理旧路径license文件（不再使用 /taichi/license、/TaiChi_CPE/license 和 /home/root/TaiChi_CPE/license）
rm -f "$APP_DIR/license" 2>/dev/null
rm -f "/TaiChi_CPE/license" 2>/dev/null
rm -f "/home/root/TaiChi_CPE/license" 2>/dev/null
log "  已清理旧路径license文件"

# 恢复数据库到 /mnt/data/（主路径），同时镜像到 /m_data/（兼容旧版）
if [ -f "$BACKUP_DIR/cpe_data.db" ]; then
    cp "$BACKUP_DIR/cpe_data.db" /mnt/data/data.db 2>/dev/null
    cp "$BACKUP_DIR/cpe_data.db" /m_data/data.db 2>/dev/null
    chmod 666 /mnt/data/data.db 2>/dev/null
    chmod 666 /m_data/data.db 2>/dev/null
    log "  已恢复CPE数据库到 /mnt/data/data.db 和 /m_data/data.db"
fi
# 保留旧版配置作为备份参考，不覆盖新版 config.json（避免丢失新增配置项）
if [ -f "$BACKUP_DIR/cpe_config.json" ]; then
    cp "$BACKUP_DIR/cpe_config.json" "$APP_DIR/config.json.bak" 2>/dev/null
    log "  已保存旧版配置为 config.json.bak（请手动合并需要保留的配置项）"
fi

log "  太极CPE 安装完成"

# 确保数据目录和文件权限正确（UBIFS只读根文件系统需要）
chmod 755 "$APP_DIR" 2>/dev/null
# license 权限确保（主路径 /mnt/data/license，镜像 /m_data/license）
chmod 644 /mnt/data/license 2>/dev/null
chmod 644 /m_data/license 2>/dev/null
chmod 644 /mnt/data/device_uid 2>/dev/null
chmod 644 /m_data/device_uid 2>/dev/null

# [5.5] 安装基带默认配置包（一键排障的"还原基带设置"使用）
log "[5.5] 安装基带默认配置包..."
BB_SRC=""
for bb_path in "$SRC_DIR/taichi/resources/baseband_default.tar.gz" "$SRC_DIR/resources/baseband_default.tar.gz" "$STAGING/taichi/resources/baseband_default.tar.gz" "$STAGING/TaiChi_CPE/resources/baseband_default.tar.gz" "$STAGING/home/root/TaiChi_CPE/resources/baseband_default.tar.gz"; do
    if [ -f "$bb_path" ]; then
        BB_SRC="$bb_path"
        break
    fi
done
if [ -n "$BB_SRC" ]; then
    mkdir -p "$APP_DIR/resources"
    cp "$BB_SRC" "$APP_DIR/resources/baseband_default.tar.gz"
    chmod 644 "$APP_DIR/resources/baseband_default.tar.gz"
    log "  基带默认配置包已安装到 $APP_DIR/resources/"
else
    log "  [警告] 升级包中无基带默认配置包（一键排障的基带还原功能将不可用）"
fi

# 清理旧版 ndp_proxy_user（v1.260902.1 起 NDP 代答已由 taichi_cpe 主进程内实现，
# 外部进程废弃：杀残留进程并删除文件，避免与主进程代答竞争）
killall -9 ndp_proxy_user 2>/dev/null
rm -f "$APP_DIR/ndp_proxy_user" 2>/dev/null

# [6] 安装 ShellCrash
log "[6] 安装 ShellCrash..."
SC_SRC=""
for sc_path in "$SRC_DIR/ShellCrash" "$STAGING/ShellCrash" "$STAGING/home/root/ShellCrash"; do
    if [ -d "$sc_path" ]; then
        SC_SRC="$sc_path"
        break
    fi
done

if [ -n "$SC_SRC" ]; then
    # ShellCrash 安装到 /home/root/ShellCrash
    # 若已有旧版ShellCrash，先备份用户配置（configs/cron/task/ui/yamls），更新后用cp -rn保留
    SC_BACKUP="/tmp/sc_config_backup"
    rm -rf "$SC_BACKUP"
    if [ -d "/home/root/ShellCrash" ]; then
        mkdir -p "$SC_BACKUP"
        for item in configs cron task ui yamls; do
            [ -d "/home/root/ShellCrash/$item" ] && cp -r "/home/root/ShellCrash/$item" "$SC_BACKUP/" 2>/dev/null
        done
        log "  已备份旧版ShellCrash用户配置"
    fi

    # 全量更新ShellCrash核心目录（libs/menus/starts/tools/jsons）
    rm -rf /home/root/ShellCrash/libs /home/root/ShellCrash/menus /home/root/ShellCrash/starts /home/root/ShellCrash/tools /home/root/ShellCrash/jsons 2>/dev/null
    mkdir -p /home/root/ShellCrash
    cp -r "$SC_SRC/"* /home/root/ShellCrash/
    chmod -R 755 /home/root/ShellCrash/*.sh 2>/dev/null
    chmod -R 755 /home/root/ShellCrash/starts/*.sh 2>/dev/null
    chmod -R 755 /home/root/ShellCrash/libs/*.sh 2>/dev/null
    # CrashCore.tar.gz is intentionally preserved. The unpacked core is too
    # large for userdata on some devices, so the backend extracts it to /run
    # and links it at start time.

    # 恢复用户配置（不覆盖新版文件 - cp -rn）
    if [ -d "$SC_BACKUP" ]; then
        for item in configs cron task ui yamls; do
            if [ -d "$SC_BACKUP/$item" ]; then
                mkdir -p "/home/root/ShellCrash/$item"
                cp -rn "$SC_BACKUP/$item/"* "/home/root/ShellCrash/$item/" 2>/dev/null
            fi
        done
        rm -rf "$SC_BACKUP"
        log "  已保留ShellCrash用户配置"
    # 兼容旧版备份目录（来自阶段3的备份）
    elif [ -d "$BACKUP_DIR/sc_configs" ]; then
        cp -r "$BACKUP_DIR/sc_configs/"* /home/root/ShellCrash/configs/ 2>/dev/null
        log "  已恢复ShellCrash配置（来自备份）"
    fi
    if [ -d "$BACKUP_DIR/sc_yamls" ]; then
        mkdir -p /home/root/ShellCrash/yamls
        cp -rn "$BACKUP_DIR/sc_yamls/"* /home/root/ShellCrash/yamls/ 2>/dev/null
        log "  已恢复ShellCrash订阅（来自备份）"
    fi
    # 确保ShellCrash.cfg包含关键字段（旧配置可能缺少）
    SC_CFG="/home/root/ShellCrash/configs/ShellCrash.cfg"
    for key in crashcore redir_mod mix_port dns_port; do
        if ! grep -q "^${key}=" "$SC_CFG" 2>/dev/null; then
            case "$key" in
                crashcore) echo "crashcore=meta" >> "$SC_CFG" ;;
                redir_mod) echo "redir_mod=redir" >> "$SC_CFG" ;;
                mix_port) echo "mix_port=7890" >> "$SC_CFG" ;;
                dns_port) echo "dns_port=1053" >> "$SC_CFG" ;;
            esac
        fi
    done
    log "  ShellCrash 已安装到 /home/root/ShellCrash"
else
    log "  [警告] 升级包中无ShellCrash"
fi

# [7] 安装启动脚本
log "[7] 安装启动脚本..."
# capfyun 防护层同步（CP100 等注入设备）：r2_init/hosts/80面板/yr_cmd wrapper
#   随 OTA 载荷 capfyun/ 一并刷新到 /mnt/data/.capfyun/。修复遗留迁移缺口：
#   旧版 OTA 只更新太极不更新防护层，注入设备 r2_init 停留 v16.3（sy-bind 版）
#   导致 80 面板数据串位（2026-08-23 事故根因）。SY108 无 /mnt/data/.capfyun/
#   目录自动跳过；旧式载荷无 capfyun/ 目录也自动跳过（向后兼容）。
# v18.1 新增：sy 舰队七件套同步（capfyun/sy/* + fake_ndsd + opennds →
#   /mnt/data/），r2_init bind 源随 OTA 保持最新——修复"OTA 刷新防护层却
#   删 sy 舰队"的 v16.4 错误决策（2026-08-24 插卡被抹除事故实证 sy bind 是
#   挡 yr-misc 抹除/断网序列的唯一手段）。
# v16.5 新增：nft_guard_v2.sh/watchdog_v2.sh（守卫独立脚本化 + cmdline 判活，
#   修复 pidfile 纯 PID 判活的 PID 复用竞态——2026-08-23 设备2 NDIS 断供 3h
#   事故：重启后 r2_init 复用 pidfile 旧 PID → 误判守卫已跑 → nft 封锁规则
#   无人清理 → tether 桥全断）。
if [ -d /mnt/data/.capfyun ]; then
    CF_LAYER=""
    for cf_path in "$STAGING/capfyun" "$SRC_DIR/capfyun"; do
        [ -d "$cf_path" ] && CF_LAYER="$cf_path" && break
    done
    if [ -n "$CF_LAYER" ]; then
        for cf_file in r2_init.sh hosts yr_cmd_app yr_cmd_app.real \
                       nft_guard_v2.sh watchdog_v2.sh; do
            [ -f "$CF_LAYER/$cf_file" ] && cp "$CF_LAYER/$cf_file" "/mnt/data/.capfyun/$cf_file"
        done
        if [ -f "$CF_LAYER/www/index.html" ]; then
            mkdir -p /mnt/data/.capfyun/www
            cp "$CF_LAYER/www/index.html" /mnt/data/.capfyun/www/index.html
        fi
        chmod 755 /mnt/data/.capfyun/r2_init.sh \
                  /mnt/data/.capfyun/yr_cmd_app \
                  /mnt/data/.capfyun/yr_cmd_app.real \
                  /mnt/data/.capfyun/nft_guard_v2.sh \
                  /mnt/data/.capfyun/watchdog_v2.sh 2>/dev/null
        # v16.5：刷新防护层后重拉守卫（r2_init 判活 cmdline 含脚本名，
        # 旧实例仍在跑则跳过；脚本内容已更新时先停旧实例保证新逻辑生效）
        for _gv in $(ps -w 2>/dev/null | grep '[n]ft_guard_v2.sh' | awk '{print $1}'); do
            kill "$_gv" 2>/dev/null
        done
        # v18.1 sy 舰队同步（载荷 capfyun/sy + fake_ndsd + opennds → /mnt/data）:
        #   这些是 r2_init bind 的源文件, sy 重编译版 yr-* 移除了 yr-misc 抹除
        #   (rm -rf /mnt/data/*)/断网(AT+CFUN=0)/reboot 序列, 是插卡防还原的
        #   核心。旧版曾在此 rm -rf /mnt/data/sy(v16.4 零 bind 教义), 2026-08-24
        #   插卡被抹除事故实证该决策错误, 已废止。载荷无 sy/ 时跳过(不破坏现场)。
        if [ -d "$CF_LAYER/sy" ]; then
            mkdir -p /mnt/data/sy
            for sf in yr-bus yr-misc yr-misc-proxy yr-modem yr-wifi yr_cmd_app; do
                if [ -f "$CF_LAYER/sy/$sf" ]; then
                    cp "$CF_LAYER/sy/$sf" "/mnt/data/sy/$sf"
                    chmod 755 "/mnt/data/sy/$sf"
                fi
            done
        fi
        if [ -f "$CF_LAYER/fake_ndsd" ]; then
            cp "$CF_LAYER/fake_ndsd" /mnt/data/fake_ndsd
            chmod 755 /mnt/data/fake_ndsd
        fi
        if [ -f "$CF_LAYER/opennds" ]; then
            cp "$CF_LAYER/opennds" /mnt/data/opennds
        fi
        # 立即重跑 r2_init 刷新 binds + 换血（md5 幂等：内容未变自动跳过；
        # sy 舰队有更新时 bind 新源并 kill 旧实例, respawn 捡起 sy 版）
        /mnt/data/.capfyun/r2_init.sh >/dev/null 2>&1 &
        log "  capfyun 防护层已刷新（r2_init v18.1/hosts/面板/yr_cmd/守卫v2/sy舰队）"
    fi
fi
# capfyun 层扩展点（CP100 等注入设备）：定制逻辑（inittab 接管/r2_init 调度/
#   守卫进程）承载于 loader_ext.sh，部署到 /mnt/data/.capfyun/（data 分区私有
#   目录，OTA 不触碰其他内容）。必须先于通用 loader 安装——覆盖 loader 前扩展
#   已就位，中间断电也不断链。SY108 无 /mnt/data/.capfyun/ 目录，自动跳过。
for ext_path in "$SRC_DIR/taichi/loader_ext.sh" "$SRC_DIR/loader_ext.sh" "$STAGING/loader_ext.sh"; do
    if [ -f "$ext_path" ] && [ -d /mnt/data/.capfyun ]; then
        cp "$ext_path" /mnt/data/.capfyun/loader_ext.sh
        chmod 755 /mnt/data/.capfyun/loader_ext.sh
        log "  loader_ext.sh 已部署到 /mnt/data/.capfyun/（capfyun 扩展）"
        break
    fi
done
# 通用 loader.sh 安装到 /home/root/（底层启动链硬编码 /home/root/loader.sh，
# 通用版通过 /mnt/data/.capfyun/loader_ext.sh 扩展点调度设备定制逻辑）
for loader_path in "$SRC_DIR/loader.sh" "$STAGING/loader.sh" "$STAGING/home/root/loader.sh"; do
    if [ -f "$loader_path" ]; then
        cp "$loader_path" /home/root/loader.sh
        chmod 755 /home/root/loader.sh
        log "  loader.sh 已安装到 /home/root/loader.sh"
        break
    fi
done
# start.sh 安装到 /taichi 目录
for start_path in "$SRC_DIR/taichi/start.sh" "$SRC_DIR/TaiChi_CPE/start.sh" "$SRC_DIR/start.sh" "$STAGING/start.sh" "$STAGING/home/root/TaiChi_CPE/start.sh"; do
    if [ -f "$start_path" ]; then
        cp "$start_path" "$APP_DIR/start.sh"
        chmod 755 "$APP_DIR/start.sh"
        log "  start.sh 已安装到 $APP_DIR/start.sh"
        break
    fi
done

# [8] 确保开机自启（inittab respawn，loader.sh后台启动后快速退出，taichi_cpe用pidfile防重复）
log "[8] 确保开机自启..."
if [ "$IS_MF650" = "1" ]; then
    # MF650：systemd 托管（v1.260829.3，与 cpe/scripts/deploy_mf650.py 保持一致）
    if [ ! -f /etc/systemd/system/taichi.service ]; then
        cat > /etc/systemd/system/taichi.service <<'UNIT_EOF'
[Unit]
Description=TaiChi CPE Web Management
After=network.target
Wants=network.target

[Service]
Type=simple
WorkingDirectory=/data/taichi
Environment=TAICHI_DATA_DIR=/data/taichi/data
ExecStart=/bin/sh /data/taichi/start.sh
Restart=on-failure
RestartSec=5
StartLimitInterval=300
StartLimitBurst=5

[Install]
WantedBy=multi-user.target
UNIT_EOF
        systemctl daemon-reload 2>/dev/null
        log "  已创建并启用 taichi.service（systemd）"
    else
        log "  taichi.service 已存在（systemd）"
    fi
    systemctl enable taichi 2>/dev/null
elif ! grep -q "^[^#]*loader.sh" /etc/inittab 2>/dev/null; then
    mount -o remount,rw / 2>/dev/null
    # 如果有被注释的行，先取消注释
    if grep -q "^#.*loader.sh" /etc/inittab 2>/dev/null; then
        sed -i 's/^#.*\(t0:5:respawn:\/home\/root\/loader.sh\)/\1/' /etc/inittab
        log "  inittab 自启动条目已取消注释"
    else
        echo "" >> /etc/inittab
        echo "# TaiChi CPE autostart" >> /etc/inittab
        echo "t0:5:respawn:/home/root/loader.sh" >> /etc/inittab
        log "  已添加inittab自启动"
    fi
    # Keep root filesystem rw - C backend needs to write database
    # mount -o remount,ro / 2>/dev/null
else
    log "  inittab自启动已存在"
fi

# v1.260827.1 清理旧版自启动残留：早期部署曾把 `/home/root/loader.sh &`
# 注入 /etc/init.d/hostname.sh，与 inittab t0 respawn 双重启动 loader。
# SY108 实测 init 为 sysvinit：锁竞争实例快速退出累计 10 次即触发
# "respawning too fast" 保护禁用 t0 条目，之后 taichi_cpe 崩溃无人拉起。
# inittab respawn 必须是唯一守护源。
if grep -q "loader.sh" /etc/init.d/hostname.sh 2>/dev/null; then
    mount -o remount,rw / 2>/dev/null
    sed -i '/loader\.sh/d' /etc/init.d/hostname.sh
    log "  已清理 hostname.sh 中的旧版 loader.sh 自启动残留"
fi

# [9.8] TAIJI 增强：授权码自动生成 + 云端域名沉井
if [ ! -s /mnt/data/license ]; then
    log "  [TAIJI] 未检出授权码，自动生成本机激活码..."
    RUID=$(head -c 16 /dev/urandom | md5sum | cut -c1-16)
    SIG="eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eA=="
    LIC_JSON="{\"v\":2,\"uid\":\"$RUID\",\"sn\":\"auto\",\"device_sn\":\"\",\"issued_at\":1747000000,\"expire_at\":0,\"type\":\"cpe\",\"sig\":\"$SIG\"}"
    LIC_B64=$(printf '%s' "$LIC_JSON" | base64 2>/dev/null | tr -d '\n')
    printf 'TC2.%s' "$LIC_B64" > /mnt/data/license
    chmod 644 /mnt/data/license
    log "  [TAIJI] 已生成本机激活码 (uid=$RUID)"
fi
mount -o remount,rw / 2>/dev/null
for TJD in mifi.5g.ssafx.cn mifi.5g.szafx.cn mqtt-5g-two.ssafx.cn mqtt-5g-two.szafx.cn raw.giteeusercontent.com; do
    grep -q "$TJD" /etc/hosts 2>/dev/null || echo "127.0.0.1 $TJD" >> /etc/hosts
done
log "  [TAIJI] 云端域名已沉井至 127.0.0.1"
sync

log "[10] 启动服务..."
EERIFY_OK=1
if [ ! -f "$APP_DIR/taichi_cpe" ] && [ ! -f "$APP_DIR/taichi_cpe_c" ]; then
    log "  [错误] 关键文件缺失: $APP_DIR/taichi_cpe"
    EERIFY_OK=0
fi
if [ ! -d "$APP_DIR/www" ]; then
    log "  [错误] 关键目录缺失: $APP_DIR/www"
    EERIFY_OK=0
fi

if [ "$EERIFY_OK" -eq 0 ]; then
    log "  [错误] 关键文件验证失败，无法启动服务！"
    log "  暂存目录保留: $STAGING"
else
    log "  关键文件验证通过，开始启动服务..."
    # inittab respawn may restart taichi_cpe immediately after the early stop step.
    # Kill it again after files and /m_data/data.db are fully restored so the new
    # process opens a stable writable database.
    killall -9 taichi_cpe 2>/dev/null
    killall -9 taichi_cpe_c 2>/dev/null
    sleep 1
    rm -f /tmp/taichi_cpe.pid  # 清除旧PID文件
    rm -f /tmp/taichi_cpe_start.lock  # 清除锁文件
    rm -f /tmp/taichi_cpe_crash_count /tmp/taichi_cpe_crash_lock
    chmod 755 /home/root/loader.sh 2>/dev/null
    chmod 755 "$APP_DIR/start.sh" 2>/dev/null
    # MF650（v1.260829.3）：systemd 托管重启——taichi.service 由部署脚本
    # ensure_service_unit 段维护，restart 由 systemd 以新二进制拉起
    if [ "$IS_MF650" = "1" ]; then
        if command -v systemctl >/dev/null 2>&1; then
            log "  通过 systemd 重启 taichi 服务"
            systemctl daemon-reload 2>/dev/null
            systemctl restart taichi 2>/dev/null
        else
            "$APP_DIR/start.sh" >> /tmp/taichi_cpe.log 2>&1 &
            log "  后端服务已启动(start.sh, port=$PORT)"
        fi
    elif grep -q "^[^#]*loader.sh" /etc/inittab 2>/dev/null; then
    # v1.260827.4 修复：telinit q 仅对新增/变更条目生效，不会重启已在退避
    # sleep 的 loader.sh 实例（SY108 实测：telinit q 后服务仍等 130s 退避自然
    # 结束才恢复）。直接终止旧实例，inittab respawn 立即拉起新实例，新实例
    # 抢锁成功并启动已就位的新 start.sh。
    # v1.260827.5 修复（孤儿 start.sh → 130s 空转循环）：仅终止 loader.sh 会把其
    # start.sh 子进程留成孤儿（PPID=1），孤儿持有的 taichi_cpe 继续运行；respawn
    # 的新 loader → start.sh → pidof 发现已运行 → 立即退出 → 130s 退避无限循环。
    # 终止顺序：loader（先停监督者）→ 残留 start.sh → taichi_cpe → 清 pidfile
    # → inittab respawn 拉起全新链条（新二进制 + 新脚本）。
    # v1.260829.4 修复：此处原有的嵌套 if grep 与 elif 分支条件完全相同
    #（MF650 分支引入时误增），消耗了 else/fi 配对导致脚本未闭合——
    # busybox ash 在 [10] 段报 "unexpected end of file (expecting fi)"，
    # OTA 安装中断在启动服务阶段且服务死透。
        LOADER_PIDS=$(ps | grep 'loader\.sh' | grep -v grep | awk '{print $1}')
        if [ -n "$LOADER_PIDS" ]; then
            kill $LOADER_PIDS 2>/dev/null
            log "  已终止旧loader实例(触发inittab立即respawn)"
        fi
        sleep 1
        START_PIDS=$(ps | grep 'taichi/start\.sh' | grep -v grep | awk '{print $1}')
        if [ -n "$START_PIDS" ]; then
            kill -9 $START_PIDS 2>/dev/null
            log "  已终止残留start.sh实例(PID: $START_PIDS)"
        fi
        killall -9 taichi_cpe 2>/dev/null
        killall -9 taichi_cpe_c 2>/dev/null
        rm -f /tmp/taichi_cpe.pid /tmp/taichi_cpe_start.lock
        if command -v telinit >/dev/null 2>&1; then
            telinit q 2>/dev/null
        fi
        log "  已通知inittab启动服务(loader.sh)"
    else
        "$APP_DIR/start.sh" >> /tmp/taichi_cpe.log 2>&1 &
        log "  后端服务已启动(start.sh, port=$PORT)"
    fi
fi

WAIT_START=0
while [ "$WAIT_START" -lt 20 ]; do
    CPE_PID=$(pidof taichi_cpe 2>/dev/null)
    if [ -n "$CPE_PID" ]; then
        break
    fi
    sleep 1
    WAIT_START=$((WAIT_START + 1))
done

# 兜底（v1.260827.4）：inittab respawn 失效（条目被禁用/telinit 不可用）时
# 20s 内服务未启动，直接拉起 start.sh 保证管理面可用性（P0）。
if [ -z "$(pidof taichi_cpe 2>/dev/null)" ] && [ -f "$APP_DIR/start.sh" ]; then
    log "  [WARN] respawn未拉起服务，兜底直接启动start.sh"
    "$APP_DIR/start.sh" >> /tmp/taichi_cpe.log 2>&1 &
    sleep 3
fi

# ==================== 阶段4: 验证 ====================

log "=========================================="
log "  安装验证"
log "=========================================="

CPE_PID=$(pidof taichi_cpe 2>/dev/null)
if [ -n "$CPE_PID" ]; then
    log "  [OK] taichi_cpe 运行中 (PID: $CPE_PID)"
else
    log "  [FAIL] taichi_cpe 未运行"
fi

if [ -d "/taichi/ShellCrash" ] || [ -d "/home/root/ShellCrash" ]; then
    log "  [OK] ShellCrash 已安装"
else
    log "  [WARN] ShellCrash 未安装"
fi

# [11] 清理临时文件（放在最后）
log "[11] 清理临时文件..."
# v1.260827.6：$STAGING 加入清理——安装结束即释放 tmpfs（SY108 实测残留
# 13.7MB 直接占 RAM）；脚本自身位于 staging 内时 rm 不影响已打开的 fd，
# busybox ash 继续从 unlink 后的 inode 读到 EOF
rm -rf "$PAYLOAD_MIRROR" "$TMP_DIR" "$BACKUP_DIR" "$STAGING" "${TMP_BASE%/}/ota.tar.gz" /tmp/ota.tar.gz /tmp/ota_rollback /run/ota_staging
log "  临时文件已清理"

EER=$(cat "$APP_DIR/VERSION" 2>/dev/null || echo "unknown")
# Web 地址：SY108=192.168.66.1(80)，非 SY108(CP100)=192.168.1.1:8686
if [ "$IS_SY108" -eq 1 ]; then
    WEB_URL="http://192.168.66.1"
else
    WEB_URL="http://192.168.1.1:${PORT}"
fi
log ""
log "=========================================="
log "  太极CPE 一键安装完成！"
log "  版本: $EER"
log "  部署路径: $APP_DIR"
log "  Web管理: $WEB_URL"
log "=========================================="
